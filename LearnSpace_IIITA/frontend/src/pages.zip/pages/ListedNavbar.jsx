
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTags, faSignOutAlt, faList } from '@fortawesome/free-solid-svg-icons';
import logo from './logo1.jpeg'; // Your logo
import defaultProfileImage from './profilePic.png'; // Default profile image

// Function to generate a random color based on the first letter of the user's name
const getColorFromName = (name) => {
    const colors = [
        'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-purple-500',
        'bg-pink-500', 'bg-teal-500', 'bg-indigo-500', 'bg-gray-500', 'bg-orange-500'
    ];
    const firstLetter = name.charAt(0).toUpperCase();
    const index = firstLetter.charCodeAt(0) % colors.length;
    return colors[index];
};

const ListedNavbar = () => {
    const { user, logout } = useAuthStore();
    const navigate = useNavigate();
    const [dropdownOpen, setDropdownOpen] = useState(false);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const toggleDropdown = () => {
        setDropdownOpen(!dropdownOpen);
    };

    const closeDropdown = () => {
        setDropdownOpen(false);
    };

    // Retrieve profile image from user object
    const profileImageSrc = user.additionalFields?.profileImage || user.profileImage || defaultProfileImage;

    return (
        <nav className="fixed top-0 left-0 w-full bg-gray-900 py-3 px-6 flex justify-between items-center z-50">
            {/* Logo Section */}
            <div className="flex items-center">
                <img src={logo} alt="Website Logo" className="h-10 mr-3" />
            </div>

            {/* Navigation Links */}
            <ul className="flex space-x-6 text-white text-lg items-center">
                <li>
                    <button onClick={() => navigate('/ProductPage')} className="hover:text-green-400 flex items-center space-x-2">
                        <FontAwesomeIcon icon={faList} />
                        <span>Products</span>
                    </button>
                </li>
                <li>
                    <button onClick={() => navigate('/sell')} className="hover:text-green-400 flex items-center space-x-2">
                        <FontAwesomeIcon icon={faTags} />
                        <span>Sell</span>
                    </button>
                </li>

                {/* Profile Section with Dropdown */}
                <li className="relative">
                    <button onClick={toggleDropdown} className="flex flex-col items-center cursor-pointer">
                        <div className={`w-12 h-12 flex items-center justify-center rounded-full text-white font-semibold text-lg ${profileImageSrc === defaultProfileImage ? getColorFromName(user.name) : ''}`}>
                            {profileImageSrc ? (
                                <img
                                    src={profileImageSrc}
                                    alt="Profile"
                                    className="w-12 h-12 rounded-full object-cover"
                                />
                            ) : (
                                <span>{user.name.charAt(0).toUpperCase()}</span>
                            )}
                        </div>
                        {user.name && <span className="text-sm text-white mt-2">{user.name}</span>}
                    </button>
                    {dropdownOpen && (
                        <div className="absolute right-0 mt-2 w-40 bg-white text-gray-800 rounded-lg shadow-lg py-2" onMouseLeave={closeDropdown}>
                            <button onClick={() => { closeDropdown(); navigate('/viewprofile'); }} className="block px-4 py-2 w-full text-left hover:bg-gray-200">
                                View Profile
                            </button>
                            <button onClick={() => { closeDropdown(); navigate('/profile'); }} className="block px-4 py-2 w-full text-left hover:bg-gray-200">
                                Edit Profile
                            </button>
                            <button onClick={handleLogout} className="block px-4 py-2 w-full text-left hover:bg-gray-200">
                                Logout
                            </button>
                        </div>
                    )}
                </li>
            </ul>
        </nav>
    );
};

export default ListedNavbar;
