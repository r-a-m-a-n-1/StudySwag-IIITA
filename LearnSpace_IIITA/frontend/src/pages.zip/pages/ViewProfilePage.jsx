

// import React, { useEffect, useState } from 'react';
// import { useAuthStore } from '../store/authStore';
// import defaultProfileImage from './profilePic.png'; // Adjust the path according to your project structure

// const ViewProfilePage = () => {
//     const { user, getProfile } = useAuthStore();
//     const [isValidBase64, setIsValidBase64] = useState(true);

//     useEffect(() => {
//         getProfile();
//     }, [getProfile]);

//     // Retrieve profileImage from additionalFields
//     const profileImageBase64 = user.additionalFields?.profileImage;
//     const isBase64Image = (str) => {
//         return /^data:image\/[a-zA-Z]+;base64,/.test(str);
//     };

//     // Set the profile image source
//     const profileImageSrc = profileImageBase64 && isBase64Image(profileImageBase64)
//         ? profileImageBase64
//         : defaultProfileImage;

//     // Validate Base64 string
//     useEffect(() => {
//         if (profileImageBase64 && !isBase64Image(profileImageBase64)) {
//             setIsValidBase64(false);
//             console.error("Invalid Base64 string for profile image:", profileImageBase64);
//         } else {
//             setIsValidBase64(true);
//         }
//     }, [profileImageBase64]);

//     const formatFieldLabel = (label) => {
//         return label
//             .replace(/([A-Z])/g, " $1")
//             .replace(/^./, (str) => str.toUpperCase());
//     };

//     return (
//         <div className="font-sans bg-gray-100 min-h-screen flex flex-col items-center py-10">
//             <div className="w-full max-w-2xl bg-white shadow-lg rounded-lg p-8">
//                 <h1 className="text-center text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-teal-400 to-emerald-500 mb-6">
//                     View Profile
//                 </h1>

//                 <div className="flex flex-col items-center mb-6">
//                     {/* Display the profile image */}
//                     <img
//                         src={profileImageSrc}
//                         alt="Profile"
//                         className="w-32 h-32 rounded-full object-cover border-4 border-green-500 shadow-md"
//                     />
//                     {!isValidBase64 && (
//                         <div className="mt-2 text-red-500">
//                             Invalid Base64 image string detected!
//                         </div>
//                     )}
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                     <div>
//                         <label className="block text-lg font-medium text-gray-700">Name</label>
//                         <p className="text-lg text-gray-700">{user.name}</p>
//                     </div>
//                     <div>
//                         <label className="block text-lg font-medium text-gray-700">Email</label>
//                         <p className="text-lg text-gray-700">{user.email}</p>
//                     </div>

//                     {/* Render additionalFields dynamically, excluding 'profileImage' */}
//                     {user.additionalFields && Object.entries(user.additionalFields).map(([key, value]) => (
//                         key !== 'profileImage' && key !=='email'&&   ( // Exclude profileImage from rendering as text
//                             <div key={key}>
//                                 <label className="block text-lg font-medium text-gray-700">{formatFieldLabel(key)}</label>
//                                 <p className="text-lg text-gray-700">{value}</p>
//                             </div>
//                         )
//                     ))}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default ViewProfilePage;


// chgn

import React, { useEffect, useState } from 'react';
import { useAuthStore } from '../store/authStore';
import defaultProfileImage from './profilePic.png'; // Adjust the path according to your project structure

const ViewProfilePage = () => {
    const { user, getProfile } = useAuthStore();
    const [isValidBase64, setIsValidBase64] = useState(true);

    useEffect(() => {
        getProfile();
    }, [getProfile]);

    const profileImageBase64 = user.additionalFields?.profileImage;
    const isBase64Image = (str) => /^data:image\/[a-zA-Z]+;base64,/.test(str);

    const profileImageSrc = profileImageBase64 && isBase64Image(profileImageBase64)
        ? profileImageBase64
        : defaultProfileImage;

    useEffect(() => {
        if (profileImageBase64 && !isBase64Image(profileImageBase64)) {
            setIsValidBase64(false);
            console.error("Invalid Base64 string for profile image:", profileImageBase64);
        } else {
            setIsValidBase64(true);
        }
    }, [profileImageBase64]);

    const formatFieldLabel = (label) =>
        label.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase());

    return (
        <div className="font-sans bg-gradient-to-br from-gray-50 via-gray-100 to-gray-200 min-h-screen flex items-center justify-center py-10">
            <div className="w-full max-w-3xl bg-white shadow-2xl rounded-lg p-8">
                <h1 className="text-center text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-teal-400 to-emerald-500 mb-8">
                    View Profile
                </h1>

                <div className="flex flex-col items-center mb-8">
                    <img
                        src={profileImageSrc}
                        alt="Profile"
                        className="w-36 h-36 rounded-full object-cover border-4 border-green-500 shadow-lg"
                    />
                    {!isValidBase64 && (
                        <div className="mt-2 text-red-500 font-semibold">
                            Invalid profile image detected!
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-lg font-semibold text-gray-700 mb-1">Name</label>
                        <p className="text-lg text-gray-800 bg-gray-50 p-3 rounded-lg shadow-sm">
                            {user.name}
                        </p>
                    </div>
                    <div>
                        <label className="block text-lg font-semibold text-gray-700 mb-1">Email</label>
                        <p className="text-lg text-gray-800 bg-gray-50 p-3 rounded-lg shadow-sm">
                            {user.email}
                        </p>
                    </div>

                    {user.additionalFields &&
                        Object.entries(user.additionalFields).map(([key, value]) =>
                            key !== "profileImage" && key !== "email" && (
                                <div key={key}>
                                    <label className="block text-lg font-semibold text-gray-700 mb-1">
                                        {formatFieldLabel(key)}
                                    </label>
                                    <p className="text-lg text-gray-800 bg-gray-50 p-3 rounded-lg shadow-sm">
                                        {value}
                                    </p>
                                </div>
                            )
                        )}
                </div>

                <div className="mt-8 flex justify-center">
                    <button
                        onClick={() => window.history.back()}
                        className="px-6 py-3 text-lg font-medium bg-gradient-to-r from-green-400 to-emerald-500 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 focus:outline-none"
                    >
                        Back to Dashboard
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ViewProfilePage;
