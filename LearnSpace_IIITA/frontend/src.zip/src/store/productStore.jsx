// src/store/productStore.js

import React, { createContext, useContext, useState } from 'react';

// Create Product Context
const ProductContext = createContext();

// Product Provider component
export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);

  // Function to add a new product
  const addProduct = (productData) => {
    setProducts((prevProducts) => [
      ...prevProducts,
      { id: Date.now(), ...productData }, // Add a unique ID to each product
    ]);
  };

  // Provide the products and addProduct function to the context
  return (
    <ProductContext.Provider value={{ products, addProduct }}>
      {children}
    </ProductContext.Provider>
  );
};

// Custom hook to use product context
export const useProductStore = () => {
  return useContext(ProductContext);
};
