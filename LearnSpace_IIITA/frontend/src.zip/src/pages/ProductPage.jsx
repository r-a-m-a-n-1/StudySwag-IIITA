// src/pages/ProductPage.jsx

import React from 'react';
import { useProductStore } from '../store/productStore'; // Import the product store
import ProductNavbar from './ProductPageNavbar'; // Make sure the path is correct
import './ProductPage.css'; // Ensure your CSS file is correctly imported

const ProductPage = () => {
  const { products } = useProductStore(); // Get products from context

  return (
    <div className='product-page'>
      <ProductNavbar />
      <div className='search-bar w-full'>
        <input
          type='text'
          placeholder='Search for products...'
          className='w-full py-2 px-4 bg-gray-800 text-white rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500'
        />
      </div>
      <div className='flex-1 flex items-center justify-center'>
        <h1 className='text-5xl font-bold bg-gradient-to-r from-green-400 to-emerald-600 text-transparent bg-clip-text'>
          Welcome to Product Page
        </h1>
      </div>

      {/* Product Cards */}
      <div className="product-grid">
        {products.length === 0 ? (
          <p>No products added yet</p>
        ) : (
          products.map((product) => (
            <div key={product.id} className="product-card">
              <img
                src={product.image} // Directly use the image URL
                alt={product.name}
                className="product-image"
              />
              <h2>{product.name}</h2>
              <p>{product.description}</p>
              <p>Price: ${product.price}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ProductPage;
