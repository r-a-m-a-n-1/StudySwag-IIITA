import React, { useState, useEffect } from 'react';
import { useAuthStore } from "../store/authStore"; // Import the authentication store
import { useNavigate } from 'react-router-dom'; // Import useNavigate from react-router-dom
import logo from './logo1.jpeg'; // Ensure the logo file path is correct

const fullText = "Welcome to Product Page";

const ProductNavbar = () => {
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(true);
  const [textIndex, setTextIndex] = useState(0);
  const { logout } = useAuthStore(); // Get the logout function from the auth store
  const navigate = useNavigate(); // Use the navigate function for navigation

  useEffect(() => {
    const typingSpeed = 75;
    const deletingSpeed = 100;
    const delayBetweenCycles = 1500;

    if (isTyping) {
      if (textIndex < fullText.length) {
        const timer = setTimeout(() => {
          setDisplayedText(fullText.slice(0, textIndex + 1));
          setTextIndex(textIndex + 1);
        }, typingSpeed);
        return () => clearTimeout(timer);
      } else {
        setTimeout(() => setIsTyping(false), delayBetweenCycles);
      }
    } else {
      if (textIndex > 0) {
        const timer = setTimeout(() => {
          setDisplayedText(fullText.slice(0, textIndex - 1));
          setTextIndex(textIndex - 1);
        }, deletingSpeed);
        return () => clearTimeout(timer);
      } else {
        setTimeout(() => setIsTyping(true), delayBetweenCycles);
      }
    }
  }, [textIndex, isTyping]);

  // Function to handle logout
  const handleLogout = () => {
    logout(); // Use the logout function from useAuthStore
    console.log("User logged out");
  };

  // Function to handle navigating to the Sell page
  const handleSellClick = () => {
    navigate('/sell'); // Navigate to the Sell page
  };

  return (
    <nav className="fixed top-0 left-0 w-full bg-gray-900 p-4 flex justify-between items-center shadow-lg z-50">
      {/* Logo and animated welcome text */}
      <div className="flex items-center">
        <img src={logo} alt="Website Logo" className="h-10 mr-3" />
        <span className="text-green-400 text-xl font-bold overflow-hidden whitespace-nowrap border-r-2 border-orange-500 pr-2">
          {displayedText}
        </span>
      </div>

      {/* Navigation links */}
      <ul className="flex space-x-6 text-white text-lg">
        <li>
          <button className="hover:text-green-400" onClick={handleSellClick}>
            Sell
          </button>
        </li>
        <li>
          <button className="hover:text-green-400" onClick={() => console.log('Categories clicked')}>
            Categories
          </button>
        </li>
        <li>
          <button className="hover:text-green-400" onClick={() => console.log('Settings clicked')}>
            Settings
          </button>
        </li>
        <li>
          <button className="hover:text-green-400" onClick={handleLogout}>
            Logout
          </button>
        </li>
      </ul>
    </nav>
  );
}

export default ProductNavbar;
