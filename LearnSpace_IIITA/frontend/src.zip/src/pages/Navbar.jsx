import React, { useState, useEffect } from 'react';
import logo from './logo1.jpeg'; // Ensure the logo file path is correct

const fullText = "Welcome to the IIITA";

function Navbar() {
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(true);
  const [textIndex, setTextIndex] = useState(0);

  useEffect(() => {
    const typingSpeed = 75;
    const deletingSpeed = 100;
    const delayBetweenCycles = 1500;

    if (isTyping) {
      if (textIndex < fullText.length) {
        const timer = setTimeout(() => {
          setDisplayedText(fullText.slice(0, textIndex + 1));
          setTextIndex(textIndex + 1);
        }, typingSpeed);
        return () => clearTimeout(timer);
      } else {
        setTimeout(() => setIsTyping(false), delayBetweenCycles);
      }
    } else {
      if (textIndex > 0) {
        const timer = setTimeout(() => {
          setDisplayedText(fullText.slice(0, textIndex - 1));
          setTextIndex(textIndex - 1);
        }, deletingSpeed);
        return () => clearTimeout(timer);
      } else {
        setTimeout(() => setIsTyping(true), delayBetweenCycles);
      }
    }
  }, [textIndex, isTyping]);

  return (
    <nav className="fixed top-0 left-0 w-full bg-blue-700 p-4 flex justify-between items-center shadow-lg z-50">
      {/* Ensure logo and text alignment */}
      <div className="flex items-center">
        <img src={logo} alt="Website Logo" className="h-10 mr-3" />
        <span className="text-red-500 text-xl font-bold overflow-hidden whitespace-nowrap border-r-2 border-orange-500 pr-2 animate-pulse">
          {displayedText}
        </span>
      </div>
      <ul className="flex space-x-6 text-white text-lg">
        <li><a href="/" className="hover:text-orange-500">Home</a></li>
        <li><a href="/about" className="hover:text-orange-500">About</a></li>
        <li><a href="/login" className="hover:text-orange-500">Login</a></li>
        <li><a href="/signup" className="hover:text-orange-500">Signup</a></li>
      </ul>
    </nav>
  );
}

export default Navbar;
