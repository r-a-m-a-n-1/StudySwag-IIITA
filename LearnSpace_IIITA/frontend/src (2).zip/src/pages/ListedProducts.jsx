// import React, { useEffect, useState } from 'react';
// import { useAuthStore } from '../store/authStore';

// const ListedProducts = () => {
//     const { user } = useAuthStore();
//     const [products, setProducts] = useState([]);

//     useEffect(() => {
//         const fetchListedProducts = async () => {
//             try {
//                 const response = await fetch(`http://localhost:5000/api/products?userId=${user.id}`);
//                 const data = await response.json();
//                 if (response.ok) {
//                     setProducts(data);
//                 } else {
//                     alert(data.message || 'Failed to load products.');
//                 }
//             } catch (error) {
//                 console.error('Error:', error);
//                 alert('Failed to load products.');
//             }
//         };
//         fetchListedProducts();
//     }, [user.id]);

//     const handleDeleteProduct = async (productId) => {
//         try {
//             const response = await fetch(`http://localhost:5000/api/products/${productId}`, {
//                 method: 'DELETE',
//             });
//             if (response.ok) {
//                 setProducts(products.filter((product) => product.id !== productId));
//                 alert('Product deleted successfully');
//             } else {
//                 alert('Failed to delete product');
//             }
//         } catch (error) {
//             console.error('Error:', error);
//             alert('Failed to delete product');
//         }
//     };

//     return (
//         <div className="max-w-3xl mx-auto p-4 mt-10 bg-white rounded-lg shadow-lg">
//             <h2 className="text-2xl font-semibold text-gray-800 text-center mb-6">My Listed Products</h2>
//             {products.length > 0 ? (
//                 <ul>
//                     {products.map((product) => (
//                         <li key={product.id} className="mb-4 p-4 border rounded-md shadow">
//                             <h3 className="text-lg font-bold">{product.productName}</h3>
//                             <p className="text-gray-700">{product.description}</p>
//                             <p className="text-gray-500">Selling Price: ${product.sellingPrice}</p>
//                             <button
//                                 onClick={() => handleDeleteProduct(product.id)}
//                                 className="mt-2 bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
//                             >
//                                 Delete
//                             </button>
//                         </li>
//                     ))}
//                 </ul>
//             ) : (
//                 <p className="text-center text-gray-600">No products listed yet.</p>
//             )}
//         </div>
//     );
// };

// export default ListedProducts;


// // chg
// import React, { useEffect, useState } from 'react';
// import ListedNavbar from './ListedNavbar'; // Navbar specific to this page
// import { useAuthStore } from '../store/authStore';

// const ListedProducts = () => {
//     const { user } = useAuthStore();
//     const [products, setProducts] = useState([]);

//     useEffect(() => {
//         const fetchListedProducts = async () => {
//             try {
//                 const response = await fetch(`http://localhost:5000/api/products?userId=${user.id}`);
//                 const data = await response.json();
//                 if (response.ok) {
//                     setProducts(data);
//                 } else {
//                     alert(data.message || 'Failed to load products.');
//                 }
//             } catch (error) {
//                 console.error('Error:', error);
//                 alert('Failed to load products.');
//             }
//         };
//         fetchListedProducts();
//     }, [user.id]);

//     const handleDeleteProduct = async (productId) => {
//         try {
//             const response = await fetch(`http://localhost:5000/api/products/${productId}`, {
//                 method: 'DELETE',
//             });
//             if (response.ok) {
//                 setProducts(products.filter((product) => product.id !== productId));
//                 alert('Product deleted successfully');
//             } else {
//                 alert('Failed to delete product');
//             }
//         } catch (error) {
//             console.error('Error:', error);
//             alert('Failed to delete product');
//         }
//     };

//     return (
//         <div>
//             {/* Include the ListedNavbar */}
//             <ListedNavbar />
            
//             {/* Main content of the page */}
//             <div className="max-w-3xl mx-auto p-6 mt-10 bg-white rounded-lg shadow-lg">
//                 <h2 className="text-2xl font-semibold text-gray-800 text-center mb-6">My Listed Products</h2>
//                 {products.length > 0 ? (
//                     <ul>
//                         {products.map((product) => (
//                             <li key={product.id} className="mb-4 p-4 border rounded-md shadow-md">
//                                 <h3 className="text-lg font-bold">{product.productName}</h3>
//                                 <p className="text-gray-700">{product.description}</p>
//                                 <p className="text-gray-500">Selling Price: ${product.sellingPrice}</p>
//                                 <button
//                                     onClick={() => handleDeleteProduct(product.id)}
//                                     className="mt-2 bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
//                                 >
//                                     Delete
//                                 </button>
//                             </li>
//                         ))}
//                     </ul>
//                 ) : (
//                     <p className="text-center text-gray-600">No products listed yet.</p>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default ListedProducts;


// chan44
import React, { useEffect, useState } from 'react';
import ListedNavbar from './ListedNavbar'; // Navbar specific to this page
import { useAuthStore } from '../store/authStore';

const ListedProducts = () => {
    const { user } = useAuthStore();
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);  // To show loading state while fetching products

    useEffect(() => {
        const fetchListedProducts = async () => {
            if (!user || !user.email) {
                // If user is not logged in or email is not available, do not fetch products
                alert('User is not authenticated.');
                return;
            }

            try {
                const response = await fetch(`http://localhost:5000/api/products?userId=${user.email}`); // Use email or userId
                const data = await response.json();

                if (response.ok) {
                    setProducts(data.products); // Assuming 'products' is the key for the array in the API response
                } else {
                    alert(data.message || 'Failed to load products.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to load products.');
            } finally {
                setLoading(false); // Set loading to false once fetch is completed
            }
        };

        fetchListedProducts();
    }, [user.email]); // Fetch data whenever the user email changes

    const handleDeleteProduct = async (productId) => {
        try {
            const response = await fetch(`http://localhost:5000/api/products/${productId}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                // Filter out the deleted product from the current state
                setProducts(products.filter((product) => product._id !== productId));
                alert('Product deleted successfully');
            } else {
                alert('Failed to delete product');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to delete product');
        }
    };

    return (
        <div>
            {/* Include the ListedNavbar */}
            <ListedNavbar />

            {/* Main content of the page */}
            <div className="max-w-3xl mx-auto p-6 mt-10 bg-white rounded-lg shadow-lg">
                <h2 className="text-2xl font-semibold text-gray-800 text-center mb-6">My Listed Products</h2>

                {loading ? (
                    <p className="text-center text-gray-600">Loading products...</p>
                ) : (
                    <>
                        {products.length > 0 ? (
                            <ul>
                                {products.map((product) => (
                                    <li key={product._id} className="mb-4 p-4 border rounded-md shadow-md">
                                        <h3 className="text-lg font-bold">{product.productName}</h3>
                                        <p className="text-gray-700">{product.description}</p>
                                        <p className="text-gray-500">Selling Price: ₹{product.sellingPrice}</p>
                                        <button
                                            onClick={() => handleDeleteProduct(product._id)} // Use `_id` for MongoDB
                                            className="mt-2 bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
                                        >
                                            Delete
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center text-gray-600">No products listed yet.</p>
                        )}
                    </>
                )}
            </div>
        </div>
    );
};

export default ListedProducts;
