// // src/pages/SellPage.jsx
// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { useProductStore } from '../store/productStore'; 
// import SellNavbar from './SellNavbar'; 

// const SellPage = () => {
//   const { fetchProducts } = useProductStore();
//   const [product, setProduct] = useState({
//     productName: '',
//     companyName: '',
//     originalPrice: '',
//     sellingPrice: '',
//     image: null,
//   });
  
//   const [loading, setLoading] = useState(false);
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     const { name, value, files } = e.target;
//     setProduct({ 
//       ...product, 
//       [name]: files ? files[0] : value
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (product.originalPrice <= 0 || product.sellingPrice <= 0) {
//       alert('Price values must be greater than zero.');
//       return;
//     }

//     setLoading(true); // Set loading state to true

//     const formData = new FormData();
//     formData.append('productName', product.productName);
//     formData.append('companyName', product.companyName);
//     formData.append('originalPrice', product.originalPrice);
//     formData.append('sellingPrice', product.sellingPrice);
//     formData.append('image', product.image);

//     try {
//       const res = await fetch('http://localhost:5000/api/products', {
//         method: 'POST',
//         body: formData,
//       });

//       if (res.ok) {
//         alert('Product added successfully!');
//         fetchProducts(); // Refresh product list after adding new product
//         setProduct({ productName: '', companyName: '', originalPrice: '', sellingPrice: '', image: null }); // Reset form
//         navigate('/ProductPage'); // Redirect to ProductPage
//       } else {
//         const errorData = await res.json();
//         alert(`Failed to add product: ${errorData.message || 'Unknown error'}`);
//       }
//     } catch (error) {
//       console.error('Error:', error);
//       alert('An error occurred while adding the product.');
//     } finally {
//       setLoading(false); // Reset loading state
//     }
//   };

//   return (
//     <div>
//       <SellNavbar />
//       <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded-lg shadow-lg">
//         <h2 className="text-2xl font-semibold mb-6 text-gray-700 text-center">Add a New Product</h2>
//         <form onSubmit={handleSubmit}>
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="productName">
//               Product Name
//             </label>
//             <input 
//               type="text" 
//               name="productName" 
//               value={product.productName} 
//               onChange={handleChange} 
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter product name"
//             />
//           </div>
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="companyName">
//               Company Name
//             </label>
//             <input 
//               type="text" 
//               name="companyName" 
//               value={product.companyName} 
//               onChange={handleChange} 
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter company name"
//             />
//           </div>
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="originalPrice">
//               Original Price
//             </label>
//             <input 
//               type="number" 
//               name="originalPrice" 
//               value={product.originalPrice} 
//               onChange={handleChange} 
//               required
//               min="0"
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter original price"
//             />
//           </div>
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="sellingPrice">
//               Selling Price
//             </label>
//             <input 
//               type="number" 
//               name="sellingPrice" 
//               value={product.sellingPrice} 
//               onChange={handleChange} 
//               required
//               min="0"
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter selling price"
//             />
//           </div>
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="image">
//               Upload Image
//             </label>
//             <input 
//               type="file" 
//               name="image" 
//               onChange={handleChange} 
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//             />
//           </div>
//           <div className="flex items-center justify-between">
//             <button 
//               type="submit" 
//               disabled={loading} // Disable button while loading
//               className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
//             >
//               {loading ? 'Adding...' : 'Add Product'}
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default SellPage;


// chagn

// src/pages/SellPage.jsx
// 

// 

// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { useProductStore } from '../store/productStore';
// import SellNavbar from './SellNavbar';

// const SellPage = () => {
//   const { fetchProducts } = useProductStore();
//   const [product, setProduct] = useState({
//     productName: '',
//     companyName: '',
//     originalPrice: '',
//     sellingPrice: '',
//     description: '',
//     image: null,
//     category: '', // Category input field
//   });

//   const [loading, setLoading] = useState(false);
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     const { name, value, files } = e.target;
//     setProduct({
//       ...product,
//       [name]: files ? files[0] : value,
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (product.originalPrice <= 0 || product.sellingPrice <= 0) {
//       alert('Price values must be greater than zero.');
//       return;
//     }

//     setLoading(true);

//     const formData = new FormData();
//     formData.append('productName', product.productName);
//     formData.append('companyName', product.companyName);
//     formData.append('originalPrice', product.originalPrice);
//     formData.append('sellingPrice', product.sellingPrice);
//     formData.append('description', product.description);
//     formData.append('image', product.image);
//     formData.append('category', product.category); // Appending the manually entered category

//     try {
//       const res = await fetch('http://localhost:5000/api/products', {
//         method: 'POST',
//         body: formData,
//       });

//       if (res.ok) {
//         alert('Product added successfully!');
//         fetchProducts(); // Refresh product list after adding new product
//         setProduct({
//           productName: '',
//           companyName: '',
//           originalPrice: '',
//           sellingPrice: '',
//           description: '',
//           image: null,
//           category: '', // Reset category
//         });
//         navigate('/ProductPage'); // Redirect to ProductPage
//       } else {
//         const errorData = await res.json();
//         alert(`Failed to add product: ${errorData.message || 'Unknown error'}`);
//       }
//     } catch (error) {
//       console.error('Error:', error);
//       alert('An error occurred while adding the product.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div>
//       <SellNavbar />
//       <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded-lg shadow-lg">
//         <h2 className="text-2xl font-semibold mb-6 text-gray-700 text-center">Add a New Product</h2>
//         <form onSubmit={handleSubmit}>
//           {/* Product Name */}
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="productName">
//               Product Name
//             </label>
//             <input
//               type="text"
//               name="productName"
//               value={product.productName}
//               onChange={handleChange}
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter product name"
//             />
//           </div>

//           {/* Company Name */}
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="companyName">
//               Company Name
//             </label>
//             <input
//               type="text"
//               name="companyName"
//               value={product.companyName}
//               onChange={handleChange}
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter company name"
//             />
//           </div>

//           {/* Original Price */}
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="originalPrice">
//               Original Price
//             </label>
//             <input
//               type="number"
//               name="originalPrice"
//               value={product.originalPrice}
//               onChange={handleChange}
//               required
//               min="0"
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter original price"
//             />
//           </div>

//           {/* Selling Price */}
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="sellingPrice">
//               Selling Price
//             </label>
//             <input
//               type="number"
//               name="sellingPrice"
//               value={product.sellingPrice}
//               onChange={handleChange}
//               required
//               min="0"
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter selling price"
//             />
//           </div>

//           {/* Product Description */}
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
//               Product Description
//             </label>
//             <textarea
//               name="description"
//               value={product.description}
//               onChange={handleChange}
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter product description"
//             />
//           </div>

//           {/* Category Input */}
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="category">
//               Product Category
//             </label>
//             <input
//               type="text"
//               name="category"
//               value={product.category}
//               onChange={handleChange}
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//               placeholder="Enter product category"
//             />
//           </div>

//           {/* Image Upload */}
//           <div className="mb-4">
//             <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="image">
//               Upload Image
//             </label>
//             <input
//               type="file"
//               name="image"
//               onChange={handleChange}
//               required
//               className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//             />
//           </div>

//           {/* Submit Button */}
//           <div className="flex items-center justify-between">
//             <button
//               type="submit"
//               disabled={loading} // Disable button while loading
//               className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
//             >
//               {loading ? 'Adding...' : 'Add Product'}
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default SellPage;


// ch3

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProductStore } from '../store/productStore';
import SellNavbar from './SellNavbar';

const SellPage = () => {
  const { fetchProducts } = useProductStore();
  const [product, setProduct] = useState({
    productName: '',
    companyName: '',
    originalPrice: '',
    sellingPrice: '',
    description: '',
    image: null,
    category: '', // Category input field
  });

  const [sellerInfo, setSellerInfo] = useState({
    fullName: '',
    mobileNo: '',
    email: '',
    enrollmentNo: '',
    hostelName: '',
    roomNo: '',
  });

  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Assuming you have a method to fetch the logged-in user details
  const user = JSON.parse(localStorage.getItem('user')); // Or use context/redux to get the user info

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (product.hasOwnProperty(name)) {
      setProduct({
        ...product,
        [name]: files ? files[0] : value,
      });
    } else {
      setSellerInfo({
        ...sellerInfo,
        [name]: value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (product.originalPrice <= 0 || product.sellingPrice <= 0) {
      alert('Price values must be greater than zero.');
      return;
    }

    setLoading(true);

    const formData = new FormData();
    formData.append('productName', product.productName);
    formData.append('companyName', product.companyName);
    formData.append('originalPrice', product.originalPrice);
    formData.append('sellingPrice', product.sellingPrice);
    formData.append('description', product.description);
    formData.append('image', product.image);
    formData.append('category', product.category);

    // Append seller information to formData
    formData.append('sellerFullName', sellerInfo.fullName);
    formData.append('sellerMobileNo', sellerInfo.mobileNo);
    formData.append('sellerEmail', sellerInfo.email);
    formData.append('sellerEnrollmentNo', sellerInfo.enrollmentNo);
    formData.append('sellerHostelName', sellerInfo.hostelName);
    formData.append('sellerRoomNo', sellerInfo.roomNo);
    
    // Attach the logged-in user ID or email to the product
    formData.append('userId', user.id); // Assuming user.id holds the user's ID, or you can use user.email

    try {
      const res = await fetch('http://localhost:5000/api/products', {
        method: 'POST',
        body: formData,
      });

      if (res.ok) {
        alert('Product added successfully!');
        fetchProducts(); // Refresh product list after adding new product
        setProduct({
          productName: '',
          companyName: '',
          originalPrice: '',
          sellingPrice: '',
          description: '',
          image: null,
          category: '',
        });
        setSellerInfo({
          fullName: '',
          mobileNo: '',
          email: '',
          enrollmentNo: '',
          hostelName: '',
          roomNo: '',
        });
        navigate('/ProductPage'); // Redirect to ListedProducts page to view the added product
      } else {
        const errorData = await res.json();
        alert(`Failed to add product: ${errorData.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred while adding the product.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <SellNavbar />
      <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold mb-6 text-gray-700 text-center">Add a New Product</h2>
        <form onSubmit={handleSubmit}>
          {/* Product Details Section */}
          <h3 className="text-xl font-semibold mb-4 text-gray-700">Product Details</h3>

          {/* Product Name */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="productName">
              Product Name
            </label>
            <input
              type="text"
              name="productName"
              value={product.productName}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter product name"
            />
          </div>

          {/* Company Name */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="companyName">
              Company Name
            </label>
            <input
              type="text"
              name="companyName"
              value={product.companyName}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter company name"
            />
          </div>

          {/* Original Price */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="originalPrice">
              Original Price
            </label>
            <input
              type="number"
              name="originalPrice"
              value={product.originalPrice}
              onChange={handleChange}
              required
              min="0"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter original price"
            />
          </div>

          {/* Selling Price */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="sellingPrice">
              Selling Price
            </label>
            <input
              type="number"
              name="sellingPrice"
              value={product.sellingPrice}
              onChange={handleChange}
              required
              min="0"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter selling price"
            />
          </div>

          {/* Product Description */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
              Product Description
            </label>
            <textarea
              name="description"
              value={product.description}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter product description"
            />
          </div>

          {/* Category Input */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="category">
              Product Category
            </label>
            <input
              type="text"
              name="category"
              value={product.category}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter product category"
            />
          </div>

          {/* Image Upload */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="image">
              Upload Image
            </label>
            <input
              type="file"
              name="image"
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            />
          </div>

          {/* Seller Information Section */}
          <h3 className="text-xl font-semibold mt-8 mb-4 text-gray-700">Seller Information</h3>

          {/* Full Name */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="fullName">
              Full Name
            </label>
            <input
              type="text"
              name="fullName"
              value={sellerInfo.fullName}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter your full name"
            />
          </div>

          {/* Mobile Number */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="mobileNo">
              Mobile Number
            </label>
            <input
              type="tel"
              name="mobileNo"
              value={sellerInfo.mobileNo}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter your mobile number"
            />
          </div>

          {/* Email */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={sellerInfo.email}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter your email"
            />
          </div>

          {/* Enrollment No */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="enrollmentNo">
              Enrollment No
            </label>
            <input
              type="text"
              name="enrollmentNo"
              value={sellerInfo.enrollmentNo}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter your enrollment number"
            />
          </div>

          {/* Hostel Name */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="hostelName">
              Hostel Name
            </label>
            <input
              type="text"
              name="hostelName"
              value={sellerInfo.hostelName}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter your hostel name"
            />
          </div>

          {/* Room Number */}
          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="roomNo">
              Room Number
            </label>
            <input
              type="text"
              name="roomNo"
              value={sellerInfo.roomNo}
              onChange={handleChange}
              required
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter your room number"
            />
          </div>

          {/* Submit Button */}
          <div className="mb-4">
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-2 px-4 text-white font-bold rounded focus:outline-none ${loading ? 'bg-gray-500' : 'bg-blue-500 hover:bg-blue-700'}`}
            >
              {loading ? 'Adding Product...' : 'Add Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SellPage;
